config_path = 'proto_test_config.json'
